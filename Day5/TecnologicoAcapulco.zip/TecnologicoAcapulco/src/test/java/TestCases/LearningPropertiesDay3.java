package TestCases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.HomePage;
import POM.LoginPage;

public class LearningPropertiesDay3 {

	@Test (dataProvider = "testdataClass", dataProviderClass =DataProviderExample.class)
	  public void f(String user, String pass) throws InterruptedException, IOException {
		  
		  System.out.println(user);
		  System.out.println(pass);	  
		  
		  //Cargar archivo de configuration
		  
		  Properties devFile= new Properties();
		  FileInputStream filepath= new FileInputStream("C:\\Users\\OtnielLenovo\\eclipse-workspace\\TecnologicoAcapulco\\src\\test\\java\\TestData\\dev.properties");	  
		  devFile.load(filepath);
		  
		  System.out.println(devFile.getProperty("browser"));
		  System.out.println(devFile.getProperty("url"));
		  
		  HomePage home;
		  LoginPage login = new LoginPage(devFile.getProperty("browser"),devFile.getProperty("url"));	  
		  //mngr431908
		  //uhUbagU
		  home = login.Login(user, pass);	  
		  //assert
		  Thread.sleep(1000);
		  System.out.println(home.getTitle());
		  
		  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");	
		  
		  login.CloseBroswser();
	  }
}
