package TestCases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.HomePage;
import POM.LoginPage;
import TestData.ReadingJson;


public class LearningJsonDay3 {

	
	
	  public void JsonTest() throws IOException, InterruptedException, ParseException{
		
		//This is a local class i created
		ReadingJson obj = new ReadingJson();
		  
		  System.out.println(obj.readJSONData("username"));
		  System.out.println(obj.readJSONData("password"));	  
		  
		  //Cargar archivo de configuration
		  
		  Properties devFile= new Properties();
		  FileInputStream filepath= new FileInputStream("C:\\Users\\OtnielLenovo\\eclipse-workspace\\TecnologicoAcapulco\\src\\test\\java\\TestData\\dev.properties");	  
		  devFile.load(filepath);
		  
		  System.out.println(devFile.getProperty("browser"));
		  System.out.println(devFile.getProperty("url"));
		  
		  HomePage home;
		  LoginPage login = new LoginPage(devFile.getProperty("browser"),devFile.getProperty("url"));	  
		  //mngr431908
		  //uhUbagU
		  home = login.Login(obj.readJSONData("username"), obj.readJSONData("password"));	  
          
		  //Assert
		  Thread.sleep(1000);
		  System.out.println(home.getTitle());		  
		  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");			  
		  login.CloseBroswser();
	  }
	
}
