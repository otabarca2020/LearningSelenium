package APITest;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;

import static io.restassured.RestAssured.*;


public class LearningSerializeTest {
  @Test
  public void Test1() {
	  
	  RegisterRequest req=new RegisterRequest();
	  
	  req.setEmail("eve.holt@reqres.in");
	  req.setPassword("password");
	  
	  
	  RestAssured.baseURI="https://reqres.in/";
	  //declarar el header y poner el body cuando es un POST
	  given().log().all().header("Content-Type","application/json").
	  body(req).expect().defaultParser(Parser.JSON).
	  when().post("api/register").then().log().all().assertThat().statusCode(200);
  }
}
