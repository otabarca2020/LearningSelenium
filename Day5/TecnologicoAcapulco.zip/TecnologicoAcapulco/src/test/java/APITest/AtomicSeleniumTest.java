package APITest;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;
import io.restassured.RestAssured;

public class AtomicSeleniumTest {
  
  @Test(groups= {"SmokeTest"})
  public void LoginSeleniumAPI() throws InterruptedException {
	  WebDriver driver;
	  
	  RestAssured.baseURI="https://rahulshettyacademy.com/";	  	  	  
	  LoginResponse resp= given().log().all().header("Content-Type","application/json").
	  body("{\"userEmail\":\"learning@gmail.com\",\"userPassword\":\"BD5QKJ@wVNWjqJi\"}").
	  when().post("api/ecom/auth/login").as(LoginResponse.class);	  
	  System.out.println(resp.token);
	  
	  String temp ="window.localStorage.setItem('token', '"+resp.token +"');";	  
	  System.out.println(temp);	  
      System.setProperty("webdriver.chrome.driver","C:\\chromeDriver\\chromedriver.exe");
      
      Map<String, String> mobileEmulation = new HashMap<>();
      mobileEmulation.put("deviceName", "iPad Air");      
      ChromeOptions chromeOption = new ChromeOptions();     
      chromeOption.setExperimentalOption("mobileEmulation", mobileEmulation);
          
      driver = new ChromeDriver(chromeOption);
      driver.manage().window().maximize();      
      driver.get("https://rahulshettyacademy.com/client/");
      Thread.sleep(5000);
      
      JavascriptExecutor js = (JavascriptExecutor)driver;
      js.executeScript(temp);
      driver.get("https://rahulshettyacademy.com/client/");
      Thread.sleep(5000);
      
      
  }
}
