package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	private WebDriver _driver;
	public HomePage(WebDriver driver) {
		this._driver=driver;
	}
		
	public String getTitle() {		
		
		
		//WebElement title= _driver.findElement(By.xpath("(//title[contains(text(),'Guru99 Bank Manager HomePage')])"));		
		return _driver.getTitle();	
	}

}
