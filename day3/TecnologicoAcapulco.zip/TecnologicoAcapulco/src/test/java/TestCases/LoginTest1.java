package TestCases;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import POM.HomePage;
import POM.LoginPage;

public class LoginTest1 {
	
	
	
//  @Test
//  @Parameters({"username","password"})
//  public void f(String user, String pass) throws InterruptedException {
//	  
//	  System.out.println(user);
//	  System.out.println(pass);	  
//	  HomePage home;
//	  LoginPage login = new LoginPage("Chrome","https://www.demo.guru99.com/V4/index.php");	  
//	  //mngr431908
//	  //uhUbagU
//	  home = login.Login(user, pass);	  
//	  //assert
//	  Thread.sleep(4000);
//	  System.out.println(home.getTitle());
//	  
//	  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");	  	  
//  }
	
	
// @Test (dataProvider = "testdata")
//  public void f(String user, String pass) throws InterruptedException {
//	  
//	  System.out.println(user);
//	  System.out.println(pass);	  
//	  HomePage home;
//	  LoginPage login = new LoginPage("Chrome","https://www.demo.guru99.com/V4/index.php");	  
//	  //mngr431908
//	  //uhUbagU
//	  home = login.Login(user, pass);	  
//	  //assert
//	  Thread.sleep(1000);
//	  System.out.println(home.getTitle());
//	  
//	  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");	
//	  
//	  login.CloseBroswser();
//  }
  

  
//  @DataProvider (name = "testdata")
//	public Object[][] dpMethod(){
//	  return new Object[][] {{"mngr431908","uhUbagU"}};
//	}
  
	
	///////////Llamar data provide en otra clase

@Test (dataProvider = "testdataClass", dataProviderClass =DataProviderExample.class)
  public void f(String user, String pass) throws InterruptedException {
	  
	  System.out.println(user);
	  System.out.println(pass);	  
	  HomePage home;
	  LoginPage login = new LoginPage("Chrome","https://www.demo.guru99.com/V4/index.php");	  
	  //mngr431908
	  //uhUbagU
	  home = login.Login(user, pass);	  
	  //assert
	  Thread.sleep(1000);
	  System.out.println(home.getTitle());
	  
	  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");	
	  
	  login.CloseBroswser();
  }
	
}
