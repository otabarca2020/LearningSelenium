package TestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.HomePage;
import POM.LoginPage;
import TestData.ReadExcelFile;

public class LearningExcelTestData {

	
	@Test (dataProvider = "excelData")
	  public void f(String user, String pass) throws InterruptedException, IOException {
		  
		  System.out.println(user);
		  System.out.println(pass);	  
		  
		  //Cargar archivo de configuration
		  
		  Properties devFile= new Properties();
		  FileInputStream filepath= new FileInputStream("C:\\Users\\OtnielLenovo\\eclipse-workspace\\TecnologicoAcapulco\\src\\test\\java\\TestData\\dev.properties");	  
		  devFile.load(filepath);
		  
		  System.out.println(devFile.getProperty("browser"));
		  System.out.println(devFile.getProperty("url"));
		  
		  HomePage home;
		  LoginPage login = new LoginPage(devFile.getProperty("browser"),devFile.getProperty("url"));	  
		  //mngr431908
		  //uhUbagU
		  home = login.Login(user, pass);	  
		  //assert
		  Thread.sleep(1000);
		  System.out.println(home.getTitle());
		  
		  Assert.assertEquals(home.getTitle(),"Guru99 Bank Manager HomePage");	
		  
		  login.CloseBroswser();
	  }
	
	
	@DataProvider(name="excelData")
	public Object[][] excelDataProvider() throws IOException{
		
		
		ReadExcelFile excelData = new ReadExcelFile();
		Object [][] dataArray = excelData.getExcelData("C:\\Users\\OtnielLenovo\\eclipse-workspace\\TecnologicoAcapulco\\src\\test\\java\\TestData\\TestExcel.xlsx", "Login");
				
		return dataArray;
		
	}
	
	
}
