package TestCases;

import org.testng.annotations.DataProvider;

public class DataProviderExample {
	
	
	  @DataProvider (name = "testdataClass")
		public Object[][] dpMethod(){
		  return new Object[][] {{"mngr431908","uhUbagU"}};
		}

}
