package APITest;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;

public class DeserializeTest {
  @Test
  public void f() {
  RegisterRequest req=new RegisterRequest();
	  
	  req.setEmail("eve.holt@reqres.in");
	  req.setPassword("password");	  
	  RestAssured.baseURI="https://reqres.in/";
	  //declarar el header y poner el body cuando es un POST
	  DeserializeResponse response =  given().log().all().header("Content-Type","application/json").
	  body(req).expect().defaultParser(Parser.JSON).
	  when().post("api/register").as(DeserializeResponse.class);	  
	  System.out.println("Print value after deserializing :" +response.getToken());
	  
	  Assert.assertEquals(response.getToken(), "QpwL5tke4Pnpja7X4");
	  
	  
  }
}
